# Android Dialer App

This repository contains the complete source code for a custom Android Dialer App built using web technologies and Capacitor.

## Files Structure
- `www/index.html`: The dialer interface with DTMF dial sounds, contacts, and call screens.
- `package.json`: Project dependencies (Capacitor Android).
- `capacitor.config.json`: Capacitor Android configuration.
- `.github/workflows/build-apk.yml`: Automated GitHub Actions pipeline to compile the `.apk` file for free in the cloud.

## How to get your `.apk` from GitHub:
1. Create a new GitHub repository (e.g., `dialer-app`).
2. Push all files from this project to the repository.
3. Open the **Actions** tab in your repository.
4. The workflow **Build Android APK** will run automatically.
5. Once completed (approx. 2–3 minutes), click on the run and download the **Dialer-Debug-APK** artifact.
6. Install the APK on your Android device!
